Extract into the report/ folder so that report/evidence/ is restored.
Contains the raw logs of the 36-episode paired benchmark and the demo validation runs.
Demo recordings (video, events) are already tracked in git under report/evidence/demo/.
