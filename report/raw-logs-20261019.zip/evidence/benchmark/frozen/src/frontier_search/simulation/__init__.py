"""Simulation module boundary."""
