"""Fixtures module boundary."""
