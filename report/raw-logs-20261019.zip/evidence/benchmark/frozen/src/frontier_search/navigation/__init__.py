"""Navigation module boundary."""
