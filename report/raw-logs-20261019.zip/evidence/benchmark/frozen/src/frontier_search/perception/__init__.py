"""Perception module boundary."""
